﻿# BtC-_CodeFirst
Tạo một danh sách NhanVien và PhongBan, Congty tương ứng, hiển thị ra thông tin NhanVien nam thuộc phòng Marketing và có tuổi từ 30 đến 40.
![Screenshot 2024-04-22 161902](https://github.com/ItsAzura/BtC-_CodeFirst/assets/134147330/c5e15fd2-582b-43fe-b216-a13b4b154bb1)
